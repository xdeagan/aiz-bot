//site list link
module.exports.config = {
  name: 'sites',
  invokers: ['sites'],
  help: 'List all the sites Aiz Bot',
  expandedHelp: 'Just use `>sites`...'
}

module.exports.events = {}
module.exports.events.message = (bot, message) => {
  message.channel.send(`nope`)
}
